from django.urls import path
from. import views

app_name = 'productos'

urlpatterns = [
    path('', views.Productos, name='Productos'),
    path('Bienvenida/', views.Bienvenida, name='Bienvenida'),
]
